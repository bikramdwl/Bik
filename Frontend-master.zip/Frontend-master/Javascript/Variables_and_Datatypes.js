
var z;
var a;
a=30;
let b=20;
const d=50;
let c="";
a=0;
c=Boolean(c);
let x= null;
x=100;
let p = {
    name: 'Manish',
    age: 26,
    number: 9860162514
};
let q = [3,5,7,10,30];

console.log('The addition of a and b is:',a+b);
console.log('The value of c is',c);
console.log(d);
console.log(c);
console.log(x);
console.log(p);
console.log(q);

let num1 = 20;
let num2 = 22;

function addition(num10,num20){
    let add= num10+num20;
    console.log('The sum of the two numbers is',add);
}
addition(num1,6);
